<!DOCTYPE html>
<html lang="en-us">
    <head>
        <title>Yeeeeah PHP!</title>
    </head>
    <body>
    <?php
        $comment = 'I think dogs are <strong>AWESOME</strong>';
    ?>
        <div class="comment-length"></div>
        <div>
            <?php echo $comment; ?>
        </div>
    </body>
</html>