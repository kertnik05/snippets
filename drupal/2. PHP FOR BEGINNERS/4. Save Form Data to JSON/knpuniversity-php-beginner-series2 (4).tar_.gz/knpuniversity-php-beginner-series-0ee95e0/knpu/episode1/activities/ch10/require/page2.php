<!DOCTYPE html>
<html lang="en-us">
    <head>
        <title>Page2!</title>
    </head>
    <body>
        <div class="output">
            <?php echo hal_9000(); ?>
        </div>
    </body>
</html>
