<!DOCTYPE html>
<html lang="en-us">
    <head>
        <title>Yeeeeah PHP!</title>
    </head>
    <body>
    <?php
        $pageTitle = 'Hello World';
        $pupCount = 50;
    ?>
        <h1><?php echo $pageTitle; ?></h1>

        <div class="count"><?php echo $pupCount; ?></div>

        Just a boring HTML page right now...
    </body>
</html>