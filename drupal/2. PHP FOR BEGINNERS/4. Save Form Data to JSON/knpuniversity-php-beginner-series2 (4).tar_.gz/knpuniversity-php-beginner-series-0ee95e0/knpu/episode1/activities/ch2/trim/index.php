<!DOCTYPE html>
<html lang="en-us">
    <head>
        <title>Yeeeeah PHP!</title>
    </head>
    <body>
    <?php
        $pageTitle = '  Hello World ';
    ?>
        <h1><?php echo $pageTitle; ?></h1>
    </body>
</html>