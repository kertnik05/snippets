<!DOCTYPE html>
<html lang="en-us">
    <head>
        <title>Chapter 3 already? You're killing it!</title>
    </head>
    <body>
        <ul>
            <li class="my-favorite">ice cream</li>
            <li class="my-favorite">high-fives</li>
            <li class="my-favorite">vacation</li>
        </ul>
    </body>
</html>