<?php
    function hal_9000()
    {
        return 'I\'m sorry, Dave. I\'m afraid I can\'t do that';
    }
?>

<!DOCTYPE html>
<html lang="en-us">
    <head>
        <title>Page1!</title>
    </head>
    <body>
        <div class="output">
            <?php echo hal_9000(); ?>
        </div>
    </body>
</html>
