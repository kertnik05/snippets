ERRATA
======

This is a list of things that have been updated in the script and code
but have not been updated on the screencast video.

* The audio `So, JSON is a great way to share data.` from `files-json-booleans`
is missing from the audio.