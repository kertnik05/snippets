<?php

$_POST = array(
    'name' => 'Chew Barka',
    'bio'  => 'The park, The pool or the Playground - I love to go anywhere!',
);

$_SERVER['REQUEST_METHOD'] = 'POST';
