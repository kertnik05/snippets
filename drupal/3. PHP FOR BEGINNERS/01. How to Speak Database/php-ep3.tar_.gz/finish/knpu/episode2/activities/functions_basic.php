<?php

/**
 * @param array $petArray The
 */
function save_new_pet($petArray)
{

}
