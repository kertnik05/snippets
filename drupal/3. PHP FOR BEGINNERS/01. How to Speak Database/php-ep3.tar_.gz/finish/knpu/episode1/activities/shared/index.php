<!DOCTYPE html>
<html lang="en-us">
    <head>
        <title>Yeeeeah PHP!</title>
    </head>
    <body>
        <h1>Replace me with some PHP!</h1>

        Just a boring HTML page right now...

    </body>
</html>