<!DOCTYPE html>
<html lang="en-us">
    <head>
        <title>Yeeeeah PHP!</title>
    </head>
    <body>
    <?php
        $pageTitle = 'Hello World';
    ?>
        <h1><?php echo $pageTitle; ?></h1>

        <div class="count"></div>

        Just a boring HTML page right now...
    </body>
</html>