<!DOCTYPE html>
<html lang="en-us">
    <head>
        <title>Our Functions!</title>
    </head>
    <body>
        <div class="output">
            Echo your function here...
        </div>
    </body>
</html>